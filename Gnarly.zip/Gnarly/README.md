# GNAR

To Run the above code:

  create NodeJS app
  create 3 folders named as routes,public,views in it.
  
  put the above public folder zip files into public folder.
  
  put the above views folder zip files into views folder.
  
  put index.js in routes folder.
  
  put app.js at project level.
   
   run the app file first.
   and open localhost:3000 in browser.
   
   
   
   ping me if anything goes wrong. thanks
