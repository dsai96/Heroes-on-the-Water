var express = require('express');
var router = express.Router();
var mongo = require('mongodb');
var assert = require('assert');

//var urlencodedParser = bodyParser.urlencoded({ extended: false })

var url = 'mongodb://localhost:27017/madhuri';

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index.html', { title: 'Homepage' });

});
router.get('/createevent',function(req,res,next)
{
  res.render('eventpage.html');  
})

router.get('/gallery', function(req, res, next) {
  res.render('gallery.html');
});

router.get('/contact', function(req, res, next) {
  res.render('contact_m.html', {title: 'contact'});
});

router.post('/contact', function(req, res, next) {
  res.render('contact_m.html', {title: 'contact'});
});

router.get('/donate', function(req, res, next) {
  res.render('donate_m.html', {title: 'donate'});
});

router.get('/index', function(req, res, next) {
  res.render('index_m.html', {title: 'Home'});
});
router.get('/involve', function(req, res, next) {
  res.render('involve.html', { title: 'involvepage' });

});

router.get('/about', function(req, res, next) {
  res.render('aboutHow.html', { title: 'Aboutpage' });

});


router.get('/signup', function(req, res, next) {
  res.render('signup.html', { title: 'SignUp' });
});
router.get('/print',function(req,res)
{
  res.render('submit.html')
});

router.post('/print',function(req,res)
{
  var name=req.body.first;
  console.log(name);
  res.redirect('/print');
});
/*router.get('/insert_mongodb',function(res,req)
{
  console.log("call reached");
})*/
router.get('/hello', function(req, res, next) {
  res.end('hai');

});

router.get('/distance', function(req, res, next) {
  var distance = require('google-distance');
  distance.get(
      {
        origin: '575 Bellevue Way NE,Bellevue, WA',
        destination: '15600 NE 8th St,Bellevue, WA'
      },
      function(err, data) {
        if (err) return console.log(err);
        console.log(data);
      });
});
router.get('/participate',function(req,res)
{
  res.render('participant.html')
});

router.get('/eparticipate',function(req,res)
{
  console.log("call reached");
  event=req.query.param;
  console.log(event);
  res.render('participant.html',{event:event})  
});

router.get('/volunteer',function(req,res)
{
  res.render('Valenteer.html')
});

router.get('/eventcreation',function(req,res)
{
  res.render('eventpage.html');
});

router.get('/login',function(req,res)
{
  res.render('login.html')
});

router.get('/signin', function(req,res) {
  console.log("call reached");
    var email1= req.query.email;
    var password1= req.query.password;
 // console.log(item.email);
  mongo.connect(url, function (err,db) {
    assert.equal(null, err);
    console.log("connection opened");
    console.log(password1);
    db.collection('data').findOne({email:email1,password:password1},function(err,document,response){
      assert.equal(null, err);
      console.log(document);
      if(document!=null) {
        console.log("found");
        res.send("success");
      }
      else {
        console.log("not found");
        res.send("fail");
      }
    });    
    db.close();
  });
});
router.get('/eventlogin',function(req,res) {
  console.log("call reached");
  var event=req.query.param;
  console.log(event);
  res.render("eventlogin.hbs",{event:event});
});


router.get('/esignin', function(req,res) {
  console.log("call reached");
  var email1= req.query.email;
  var password1= req.query.password;
  var event=req.query.event;
  var role=req.query.role;
  console.log(role);
  console.log(event);
  if(email!=null && passowrd !=null) {
    mongo.connect(url, function (err, db) {
      assert.equal(null, err);
      console.log("connection opened");
      console.log(password1);
      db.collection('eventregister').insertOne({
        email: email1,
        password: password1,
        event: event
      },function (err,result) {
        assert.equal(null, err);
        console.log("inserted");
        if (!err) {
          res.send("success");
        }
        else {
          res.send("fail");
        }
      });
      db.close();
    });
  }
  else {
     res.send("empty");
  }
});

router.post('/participant', function(req,res) {
  console.log("call reached");
  item = {
    firstname: req.body.firstname,
    lastname: req.body.lastname,
    email: req.body.email,
    password: req.body.password,
    street_addr: req.body.street_addr,
    city: req.body.city,
    state: req.body.state,
    zip: req.body.zip,
    story: req.body.story,
    source: 'online'
  };
  console.log(item.firstname);
  mongo.connect(url, function (err,db) {
    assert.equal(null, err);
    console.log("connection opened");
    //console.log(item.firstname);
    db.collection('participant').insertOne(item, function(err,res,result) {
      assert.equal(null, err);
      console.log('inserted');
      // res.send("sent");
      db.close();
    });
  });
});

router.post('/insert_mongodb', function(req,res) {
  console.log("call reached");
  item = {
    firstname: req.body.firstname,
    lastname: req.body.lastname,
    email: req.body.email,
    password: req.body.password,
    street_addr: req.body.street_addr,
    city: req.body.city,
    state: req.body.state,
    zip: req.body.zip,
    story: req.body.story,
    source: 'online'
  };
  console.log(item.firstname);
  mongo.connect(url, function (err,db) {
    assert.equal(null, err);
    console.log("connection opened");
    //console.log(item.firstname);
    db.collection('data').insertOne(item, function (err,res,result) {
      assert.equal(null, err);
      console.log('inserted');
     // res.send("sent");
      db.close();
    });
  });
 
});

router.get('/event_data',function(req,res,next)
{
  var allevents=[];
  var recent =[];
  var upcoming=[];

  mongo.connect(url,function(err,db)
  {
    if(err)
    {
      console.log("Unable to connect to mongodb server");
      res.render('event.hbs');
    }
    else {
      //assert.equal(null,err);
      var events = db.collection('event').find();
      var upevents = db.collection('event').find({date: {$gt: "2016-07-23"}});
      var recentevents = db.collection('event').find({date: {$lt: "2016-07-28", $gt: "2016-03-14"}});

      events.forEach(function (doc, err) {
        assert.equal(null, err);
        allevents.push(doc);
      });
      upevents.forEach(function (doc, err) {
        assert.equal(null, err);
        upcoming.push(doc);
      });
      recentevents.forEach(function (doc, err) {
        assert.equal(null, err);
        recent.push(doc);
      }, function () {
        db.close();
        res.render('event.hbs', {items: allevents, upitems: upcoming, recent: recent});
      });
    }
  });
});

router.post('/event_mongodb', function(req,res) {
  console.log("call reached");
  item = {
    eventtitle: req.body.eventtitle,
    chapter: req.body.chapter,
    date: req.body.date,
    time: req.body.time,
    street_addr: req.body.street_addr,
    city: req.body.city,
    state: req.body.state,
    zip: req.body.zip,
    eventdetails: req.body.eventdetails,
    phonenumber: req.body.phonenumber,
    email:req.body.email
  };
  console.log(item.eventtitle);
  mongo.connect(url, function(err,db) {
    assert.equal(null, err);
    console.log("connection opened");
    db.collection('event').insertOne(item, function (err,res,result) {
      assert.equal(null, err);
      console.log('inserted');
      // res.send("sent");
      db.close();
    });
  });

});


//mail module
var nodemailer=require("nodemailer");
smtpTransport = nodemailer.createTransport("SMTP",{
  service: "Gmail",
  auth: {
    user: "madhuri.illuri1@gmail.com",
    pass: "Lingamgunta"
  }
});

router.get('/sendEmail', function(req, res, next) {
  console.log("call reached");
  var mailOptions={
    to : req.query.to,
    subject :"HOW NEWSLETTER",

    text : "Thank you for Subscribing to our news letter. You will receive our news letters and more information about our mission soon."
  }
  console.log(mailOptions);
  smtpTransport.sendMail(mailOptions, function(error, response){
    if(error){
      console.log(error);
      res.send(error);
    }else{
      console.log("Message sent: " + response.message);
      res.send("sent");
    }
  });

});

module.exports = router;
