var express = require('express');
var router = express.Router();
var mongo = require('mongodb');
var assert = require('assert');
var nodemailer=require("nodemailer");
//var smtpTransport = require("nodemailer-smtp-transport")
/* GET users listing. */
/*
 Here we are configuring our SMTP Server details.
 STMP is mail server which is responsible for sending and recieving email.
 */
smtpTransport = nodemailer.createTransport("SMTP",{
  service: "Gmail",
  auth: {
    user: "madhuri.illuri1@gmail.com",
    pass: "Lingamgunta"
  }
});

/*nodemailer.use('compile',hbs(
    {
        viewPath:'views',
        extNAme:'.html'

}));
*/
router.get('/sendEmail', function(req, res, next) {
    console.log("call reached");
    var mailOptions={
        to : req.query.to,
        subject :"HOW NEWSLETTER",
        
        text : "Thank you for Subscribing to our news letter. You will receive our news letters and more information about our mission soon."
    }
    console.log(mailOptions);
    smtpTransport.sendMail(mailOptions, function(error, response){
        if(error){
            console.log(error);
            res.json(error);
        }else{
            console.log("Message sent: " + response.message);
            res.json("sent");
        }
    });

  });

router.get('/hello', function(req, res, next) {
    console.log('call');
    res.end('hai');

});



module.exports = router;
